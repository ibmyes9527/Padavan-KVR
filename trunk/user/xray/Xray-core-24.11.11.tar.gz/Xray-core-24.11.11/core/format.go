package core

//go:generate go install -v github.com/daixiang0/gci@latest
//go:generate go install -v mvdan.cc/gofumpt@latest
//go:generate go run ../infra/vformat/main.go -pwd ./..
